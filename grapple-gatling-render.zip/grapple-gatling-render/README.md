# Grapple Gatling

A 2D grappling-hook arena shooter. Anyone who opens your site and presses Start joins the same arena.

## Controls
- A / D: move. W or Space: jump.
- Left click: shoot towards the mouse.
- F: fire the grappling hook. Once it has attached, hold F to reel in.
- E: let go of the hook.
- Esc: back to the menu.

## Put it online with Render (free)

1. **Make a GitHub repository.** On github.com click New repository, name it `grapple-gatling`, then
   "uploading an existing file" and drag in everything from this folder
   (`server.js`, `package.json`, `render.yaml`, `public/index.html`). Commit.
2. **Create the service.** On render.com sign up (you can use your GitHub login), then
   New > Web Service > pick your `grapple-gatling` repository.
3. **Settings** (Render usually fills these in from the repo):
   - Runtime: Node
   - Build command: `echo "nothing to build"` (the game has no dependencies, so there is nothing to install)
   - Start command: `node server.js`
   - Instance type: Free
4. Click **Create Web Service**. After about a minute you get a link like
   `https://grapple-gatling.onrender.com`. That is the public link. Send it to anyone.

Alternative: New > Blueprint, pick the repository, and Render reads `render.yaml` for you.

## Things to know
- The free plan puts the server to sleep after about 15 minutes with nobody on it. The next visitor waits
  roughly 30 to 60 seconds for it to wake up, then it runs normally.
- The server holds up to 24 players at once. Everyone shares one arena.
- Run it on your own computer with `node server.js`, then open http://localhost:3000.
